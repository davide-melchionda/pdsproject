﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;

namespace FileShare {
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class NotificationWindow : Window
    {

        public NotificationWindow() {
            InitializeComponent();
        }
        
    }

}

