﻿namespace FileShareConsole
{
    abstract class IPCModule
    {
    }
}
